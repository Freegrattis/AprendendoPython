from PySide6.QtWidgets import QMainWindow,QMessageBox,QTableWidgetItem,QApplication
from ui_main import Ui_MainWindow
from database import Data_base

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainWindow,self).__init__()
        self.setupUi(self)
        self.setWindowTitle("Sistema de Cliente")
        self.btn_cadastro.clicked.connect(self.cadastro_cliente)
        self.btn_pesquisa.clicked.connect(self.pesquisar_cliente)
        self.btn_exclusao.clicked.connect(self.excluir_cliente)
        self.btn_alteracao.clicked.connect(self.alterar_cliente)
        self.tableWidget.cellClicked.connect(self.selecionar_cliente)

        self.db = Data_base()
        self.db.connect()
        self.db.create_table_cliente()

    def closeEvent(self, event):
        self.db.close_connection()

    def show_message(self,title,message):
        msg=QMessageBox()
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.exec()

    def cadastro_cliente(self):
        nome=self.txt_nome.text()
        cpf=self.txt_cpf.text()
        
        if nome.strip()== ""or cpf.strip()=="":
            self.show_message("Atenção!","Preencha todos os campos.")
            return 

        resp=self.db.cadastro_cliente_banco((nome,cpf))
        if resp=="ok":
            self.limpar_campo()
            self.show_message("Cadastro","Cliente cadastrado" )
        else:
            self.show_message("Alerta!","Verifique as informações")

    def pesquisar_cliente(self):
        cpf=self.txt_cpf.text()

        if not cpf.strip():
            resultados=self.db.pesquisa_cliente()
        else:
            resultados=self.db.pesquisa_cliente(cpf)
        if resultados:
            self.exibir_resultados(resultados)
        else:
            self.show_message("Atenção!","Cliente não encontrado")

    def exibir_resultados(self, resultado):
        self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)
        
        for row, data in enumerate(resultado):
            self.tableWidget.insertRow(row)
            for column, value in enumerate(data):
                self.tableWidget.setItem(row, column, QTableWidgetItem(str(value)))
    
    def excluir_cliente(self):
        cpf=self.txt_cpf.text()
        if not cpf.strip():
            self.show_message("Atenção!","Insira um CPF para ser excluido:")
            return
        exclui_msg= QMessageBox.question(self,'Excluir Cliente',f'Tem certeza que deseja excluir esse cliente?{cpf}',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if exclui_msg==QMessageBox.Yes:
            if self.db.excluir_cliente(cpf):
                self.limpar_campo()
                self.show_message("Exclusão","Cliente excluido")
                self.tableWidget.clearContents()
                self.tableWidget.setRowCount(0)
            else:
                self.show_message("Erro","Erro ao excluir cliente")

    def alterar_cliente(self):
        cpf=self.txt_cpf.text()
        if not cpf.strip():
            self.show_message("Atenção!","Insira um CPF para alterar.")
            return
        nome_cli=self.txt_nome.text()
        cpf_cli=self.txt_cpf.text()

        if not nome_cli.strip() or not cpf_cli.strip():
            self.show_message("Atenção!","Preencha os campos.")
            return
        
        if self.db.alterar_cliente(cpf,nome_cli,cpf_cli):
            self.show_message("Alteração","Alterado com sucesso!")
            self.limpar_campo()
            self.pesquisar_cliente()
        else:
            self.show_message("Erro","Não foi possivel alterar os dados")

    def limpar_campo(self):
        self.txt_nome.clear()
        self.txt_cpf.clear()

    def selecionar_cliente(self,row):
        nome_cliente=self.tableWidget.item(row,0).text()
        cpf_cliente=self.tableWidget.item(row,1).text()

        self.txt_nome.setText(nome_cliente)
        self.txt_cpf.setText(cpf_cliente)
if __name__=="__main__":
    import sys
    app =QApplication(sys.argv)

    window=MainWindow()
    window.show()
    
    
    sys.exit(app.exec())