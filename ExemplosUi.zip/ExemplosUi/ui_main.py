# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'exemplo_projeto_cadastro.ui'
##
## Created by: Qt User Interface Compiler version 6.6.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHeaderView, QLabel,
    QLineEdit, QMainWindow, QPushButton, QSizePolicy,
    QStatusBar, QTableWidget, QTableWidgetItem, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(9, 9, 781, 561))
        self.frame.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.txt_nome = QLineEdit(self.frame)
        self.txt_nome.setObjectName(u"txt_nome")
        self.txt_nome.setGeometry(QRect(290, 210, 271, 22))
        self.txt_cpf = QLineEdit(self.frame)
        self.txt_cpf.setObjectName(u"txt_cpf")
        self.txt_cpf.setGeometry(QRect(290, 260, 271, 22))
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(400, 180, 49, 16))
        self.label.setStyleSheet(u"color: rgb(0, 0, 0);\n"
"font: 700 11pt \"Segoe UI\";")
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(410, 240, 49, 16))
        self.label_2.setStyleSheet(u"color: rgb(0, 0, 0);\n"
"font: 700 11pt \"Segoe UI\";")
        self.btn_pesquisa = QPushButton(self.frame)
        self.btn_pesquisa.setObjectName(u"btn_pesquisa")
        self.btn_pesquisa.setGeometry(QRect(420, 300, 75, 24))
        self.btn_alteracao = QPushButton(self.frame)
        self.btn_alteracao.setObjectName(u"btn_alteracao")
        self.btn_alteracao.setGeometry(QRect(550, 500, 75, 24))
        self.btn_cadastro = QPushButton(self.frame)
        self.btn_cadastro.setObjectName(u"btn_cadastro")
        self.btn_cadastro.setGeometry(QRect(300, 300, 75, 24))
        self.btn_exclusao = QPushButton(self.frame)
        self.btn_exclusao.setObjectName(u"btn_exclusao")
        self.btn_exclusao.setGeometry(QRect(660, 500, 75, 24))
        self.tableWidget = QTableWidget(self.frame)
        if (self.tableWidget.columnCount() < 2):
            self.tableWidget.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(20, 160, 231, 231))
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Nome:", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"CPF:", None))
        self.btn_pesquisa.setText(QCoreApplication.translate("MainWindow", u"PESQUISA", None))
        self.btn_alteracao.setText(QCoreApplication.translate("MainWindow", u"ALTERA\u00c7\u00c3O", None))
        self.btn_cadastro.setText(QCoreApplication.translate("MainWindow", u"CADASTRO", None))
        self.btn_exclusao.setText(QCoreApplication.translate("MainWindow", u"EXCLUS\u00c3O", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"CLIENTE", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"CPF", None));
    # retranslateUi

