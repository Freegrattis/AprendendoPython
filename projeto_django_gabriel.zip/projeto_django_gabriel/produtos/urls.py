from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('produtos/', views.lista_produtos, name = 'lista_produtos'),  # URL para listar funcionários
    path('novo/', views.cria_produto, name = 'cria_produto'),
    path('editar/<int:pk>/', views.edita_produto, name = 'edita_produto'),
    path('deletar/<int:pk>/', views.deleta_produto, name = 'deleta_produto'),
]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)