from django.db import models

class Produto(models.Model):
    ESCOLHAS_VOLTAGEM = (
        (110,'110V'),
        (220,'220V')
    )
 
    ESCOLHAS_MARCA = (
        ('Microsoft','Microsoft'),
        ('Bosch','Robert Bosch'),
        ('Apple','Apple Inc'),
        ('Samsung','Samsung')
    )
 
    ESCOLHAS_TIPO = (
        ('Portátil','Portátil'),
        ('Estatico','Estatico')
    )
 
    descricao = models.CharField(max_length=100)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    quantidade = models.IntegerField()
    peso = models.DecimalField(max_digits=6,decimal_places=2)
    voltagem = models.IntegerField(choices=ESCOLHAS_VOLTAGEM)
    marca = models.CharField(choices=ESCOLHAS_MARCA,max_length=50)
    tipo = models.CharField(choices=ESCOLHAS_TIPO,max_length=50)
 
    def __str__(self):
        return self.name

