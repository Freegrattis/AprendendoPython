from django.db import models

class Funcionario(models.Model):
    nome_completo = models.CharField(max_length=100)
    edv = models.CharField(max_length=20, unique=True)
    cargo = models.CharField(max_length=100)
    setor = models.CharField(max_length=100)
    endereco = models.CharField(max_length=50)
    horario_entrada = models.TimeField()
    horario_saida = models.TimeField()
    data_admissao = models.DateField()
    foto = models.ImageField(null=True, blank=True)  # Campo para a foto

    def __str__(self):
        return self.nome_completo
