from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('funcionarios/', views.lista_funcionarios, name = 'lista_funcionarios'),  # URL para listar funcionários
    path('novo/', views.cria_funcionario, name = 'cria_funcionario'),
    path('editar/<int:pk>/', views.edita_funcionario, name = 'edita_funcionario'),
    path('deletar/<int:pk>/', views.deleta_funcionario, name = 'deleta_funcionario'),
]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)